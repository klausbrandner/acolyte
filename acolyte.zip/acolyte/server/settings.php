<?php

//----------------------------------------------------
    
    // YOUR WEBHOST
    define("HOST", "localhost");

    // YOUR USERNAME
    define("USER", "root");

    // YOUR DATABASE
    define("DATABASE", "acolyte");

    // YOUR DATABASE PASSWORD
    define("PASSWORD", "");

//----------------------------------------------------

    //YOUR ACOLYTE USER 
    define("ACOUSER", "admin");

    //YOUR ACOLYTE PW
    define("ACOPASSWORD", "admin")
?>