<?php
    
    // YOUR WEBHOST
    define("HOST", "localhost");

    // YOUR USERNAME
    define("USER", "root");

    // YOUR DATABASE
    define("DATABASE", "acolyte");

    // YOUR DATABASE PASSWORD
    define("PASSWORD", "");

?>