<?php
    
/*
    // YOUR WEBHOST
    define("HOST", "mysqlsvr50.world4you.com ");

    // YOUR USERNAME
    define("USER", "sql8580095");

    // YOUR DATABASE
    define("DATABASE", "8580095db2");

    // YOUR DATABASE PASSWORD
    define("PASSWORD", "p00ky0s");
    */


    // YOUR WEBHOST
    define("HOST", "localhost");

    // YOUR USERNAME
    define("USER", "root");

    // YOUR DATABASE
    define("DATABASE", "acolyte");

    // YOUR DATABASE PASSWORD
    define("PASSWORD", "");
?>